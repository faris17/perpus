CARA INSTALL

- buat database perpus
- import file database perpus.sql di folder database.
- extract folder applikasi ke dalam direktori htdocs.